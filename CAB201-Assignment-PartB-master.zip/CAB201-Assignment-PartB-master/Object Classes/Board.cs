﻿using System.Diagnostics;

namespace Object_Classes {
    /// <summary>
    /// Models a game board for Space Race consisting of three different types of squares
    /// 
    /// Ordinary squares, Wormhole squares and Blackhole squares.
    /// 
    /// landing on a Wormhole or Blackhole square at the end of a player's move 
    /// results in the player moving to another square
    /// 
    /// </summary>
    public static class Board {
        /// <summary>
        /// Models a game board for Space Race consisting of three different types of squares
        /// 
        /// Ordinary squares, Wormhole squares and Blackhole squares.
        /// 
        /// landing on a Wormhole or Blackhole square at the end of a player's move 
        /// results in the player moving to another square
        /// 
        /// 
        /// </summary>

        public const int NUMBER_OF_SQUARES = 56;
        public const int START_SQUARE_NUMBER = 0;
        public const int FINISH_SQUARE_NUMBER = NUMBER_OF_SQUARES - 1;

        private static Square[] squares = new Square[NUMBER_OF_SQUARES];

        public static Square[] Squares {
            get {
                Debug.Assert(squares != null, "squares != null",
                   "The game board has not been instantiated");
                return squares;
            }
        }

        public static Square StartSquare {
            get {
                return squares[START_SQUARE_NUMBER];
            }
        }


        /// <summary>
        ///  Eight Wormhole squares.
        ///  
        /// Each row represents a Wormhole square number, the square to jump forward to and the amount of fuel consumed in that jump.
        /// 
        /// For example {2, 22, 10} is a Wormhole on square 2, jumping to square 22 and using 10 units of fuel
        /// 
        /// </summary>
        private static int[,] wormHoles =
        {
            {2, 22, 10},
            {3, 9, 3},
            {5, 17, 6},
            {12, 24, 6},
            {16, 47, 15},
            {29, 38, 4},
            {40, 51, 5},
            {45, 54, 4}
        };

        /// <summary>
        ///  Eight Blackhole squares.
        ///  
        /// Each row represents a Blackhole square number, the square to jump back to and the amount of fuel consumed in that jump.
        /// 
        /// For example {10, 4, 6} is a Blackhole on square 10, jumping to square 4 and using 6 units of fuel
        /// 
        /// </summary>
        private static int[,] blackHoles =
        {
            {10, 4, 6},
            {26, 8, 18},
            {30, 19, 11},
            {35, 11, 24},
            {36, 34, 2},
            {49, 13, 36},
            {52, 41, 11},
            {53, 42, 11}
        };


        /// <summary>
        /// Parameterless Constructor
        /// Initialises a board consisting of a mix of Ordinary Squares,
        ///     Wormhole Squares and Blackhole Squares.
        /// 
        /// Pre:  none
        /// Post: board is constructed
        /// </summary>
        public static void SetUpBoard() {

            // Create the 'start' square where all players will start.
            squares[START_SQUARE_NUMBER] = new Square("Start", START_SQUARE_NUMBER);

            // Create the main part of the board, squares 1 .. 54

            //
            //   Need to call the appropriate constructor for each square
            //       either new Square(...),  new WormholeSquare(...) or new BlackholeSquare(...)
            //


            string squareName = "";

            for (int CURRENT_SQUARE_NUMBER = (START_SQUARE_NUMBER + 1); CURRENT_SQUARE_NUMBER < FINISH_SQUARE_NUMBER; CURRENT_SQUARE_NUMBER++)
            {
                //Set the square name as the string form of the number   
                squareName = string.Format("{0}",CURRENT_SQUARE_NUMBER);

                //Check if the current square is a blackhole, wormhole or normal

                //Blackhole
                int b_dest_num; //Position of the destination square
                int b_fuel_num; //Fuel consumed
                //Wormhole
                int w_dest_num;
                int w_fuel_num;

                //Check blackhole squares
                FindDestSquare(blackHoles, CURRENT_SQUARE_NUMBER, out b_dest_num, out b_fuel_num);

                //Check wormhole squares
                FindDestSquare(wormHoles, CURRENT_SQUARE_NUMBER, out w_dest_num, out w_fuel_num);

                if (b_fuel_num > 0) //If blackhole
                {
                    squares[CURRENT_SQUARE_NUMBER] = new BlackholeSquare(squareName, CURRENT_SQUARE_NUMBER, b_dest_num, b_fuel_num);
                } else if (w_fuel_num > 0) //If wormhole
                {
                    squares[CURRENT_SQUARE_NUMBER] = new WormholeSquare(squareName, CURRENT_SQUARE_NUMBER, w_dest_num, w_fuel_num);
                } else //If the square is normal, set it to the base square class
                {
                    squares[CURRENT_SQUARE_NUMBER] = new Square(squareName, CURRENT_SQUARE_NUMBER);
                }
            }

            // Create the 'finish' square.
            squares[FINISH_SQUARE_NUMBER] = new Square("Finish", FINISH_SQUARE_NUMBER);
        } // end SetUpBoard

/// <summary>
/// Finds the destination square and the amount of fuel used for either a 
/// Wormhole or Blackhole Square.
/// 
/// pre: squareNum is either a Wormhole or Blackhole square number
/// post: destNum and amount are assigned correct values.
/// </summary>
/// <param name="holes">a 2D array representing either the Wormholes or Blackholes squares information</param>
/// <param name="squareNum"> a square number of either a Wormhole or Blackhole square</param>
/// <param name="destNum"> destination square's number</param>
/// <param name="amount"> amount of fuel used to jump to the destination square</param>
private static void FindDestSquare(int[,] holes, int squareNum, out int destNum, out int amount) {
const int start = 0, exit = 1, fuel = 2;
destNum = 0; amount = 0;

//For either blackholes or wormholes, loop through the array
for (int current_hole = 0; current_hole < holes.GetLength(0); current_hole++)
{
    //Check if the current black/worm hole is at the square specified 
    if (holes[current_hole, start] == squareNum)
    {
        //Set the out variables
        destNum = holes[current_hole, exit]; //Position of the destination square
        amount = holes[current_hole, fuel]; //Fuel consumed
    }
}
} //end FindDestSquare

} //end class Board
}
 